
    
        function log(){
            var x=Number(document.getElementById("input1").value);
           
            if(x<10 && x==0){
                alert("not valid number");
            }

        }
   
    
